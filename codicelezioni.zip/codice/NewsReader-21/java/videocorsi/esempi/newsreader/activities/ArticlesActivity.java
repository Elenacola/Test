package videocorsi.esempi.newsreader.activities;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import videocorsi.esempi.newsreader.R;

/* Created by creareapp.com */

public class ArticlesActivity extends ListActivity
{
    private ArticlesAdapter adapter=null;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        NewsProvider provider=new NewsProvider();
        adapter=new ArticlesAdapter(provider.getArticles());

        getListView().setAdapter(adapter);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        switch(id)
        {
            case R.id.second_activity:
                Intent i=new Intent(this,ManagerActivity.class);
                startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}