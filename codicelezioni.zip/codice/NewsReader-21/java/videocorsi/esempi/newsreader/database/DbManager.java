package videocorsi.esempi.newsreader.database;


/* Created by creareapp.com */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class DbManager
{
    private DbHelper helper = null;

    public DbManager(Context context)
    {
        helper=new DbHelper(context);
    }

    public void newProvider(ContentValues values)
    {
        SQLiteDatabase db=helper.getWritableDatabase();
        db.insert("providers",null,values);
    }

    public List<String> getProviders()
    {
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor crs=db.query("providers",null,null,null,null,null,null);

        List<String> res=new ArrayList<String>();
        while(crs.moveToNext())
        {
            int pos=crs.getColumnIndex("name");
            res.add( crs.getString(pos) );
        }
        return res;
    }

}
