package videocorsi.esempi.newsreader;


/* Created by creareapp.com */

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DbManager
{
    private DbHelper helper = null;

    public DbManager(Context context)
    {
        helper=new DbHelper(context);
    }

    public List<String> getProviders()
    {
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor crs=db.query("providers",null,null,null,null,null,null);

        List<String> res=new ArrayList<String>();

        while(crs.moveToNext())
        {
            String tmp=crs.getString(crs.getColumnIndex("title"));
            res.add(tmp);
        }
        return res;

    }
   
}
