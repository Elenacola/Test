package videocorsi.esempi.newsreader.activities;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import videocorsi.esempi.newsreader.R;
import videocorsi.esempi.newsreader.beans.ArticleInfo;
import videocorsi.esempi.newsreader.beans.ProviderInfo;
import videocorsi.esempi.newsreader.database.DbManager;

/* Created by creareapp.com */

public class ArticlesActivity extends ListActivity
{
    private CursorAdapter adapter=null;
    private DbManager db=new DbManager(this);

    @Override
    protected void onStart()
    {
        super.onStart();
        if (adapter==null)
        {
            adapter= new CursorAdapter(this, db.getArticles(), false) {
                @Override
                public View newView(Context context, Cursor cursor, ViewGroup viewGroup)
                {
                    View v=LayoutInflater.from(context).inflate(R.layout.article_layout,null);
                    return v;
                }

                @Override
                public void bindView(View view, Context context, Cursor cursor)
                {
                    TextView txt= (TextView) view.findViewById(R.id.title);
                    txt.setText(cursor.getString(cursor.getColumnIndex("title")));
                    txt= (TextView) view.findViewById(R.id.url);
                    txt.setText(cursor.getString(cursor.getColumnIndex("url")).substring(0,40)+"...");
                }

                @Override
                public Object getItem(int position)
                {
                    Cursor crs=getCursor();
                    crs.moveToPosition(position);
                    String title=crs.getString(crs.getColumnIndex("title"));
                    String url=crs.getString(crs.getColumnIndex("url"));
                    ArticleInfo pi=new ArticleInfo(title,url);
                    return pi;
                }


            };

            getListView().setAdapter(adapter);

            getListView().setOnItemClickListener(new AdapterView.OnItemClickListener()
            {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                {
                    ArticleInfo ai= (ArticleInfo) adapter.getItem(position);
                    WebView web=new WebView(ArticlesActivity.this);
                    web.setWebViewClient(new WebViewClient());
                    web.loadUrl(ai.getUrl());
                    AlertDialog.Builder dialog=new AlertDialog.Builder(ArticlesActivity.this);
                    dialog.setView(web);
                    dialog.setPositiveButton("Chiudi", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            dialog.dismiss();
                        }
                    });
                    dialog.show();
                }
            });

        } 
        else
            adapter.swapCursor(db.getArticles());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        switch(id)
        {
            case R.id.second_activity:
                Intent i=new Intent(this,ManagerActivity.class);
                startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}