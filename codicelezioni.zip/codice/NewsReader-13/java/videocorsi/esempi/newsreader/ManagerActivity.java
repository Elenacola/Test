package videocorsi.esempi.newsreader;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;

/* Created by creareapp.com */

public class ManagerActivity extends ListActivity
{
    private ArrayAdapter adapter=null;
    private NewsProvider provider=new NewsProvider();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        adapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1,provider.getProvider());

        getListView().setAdapter(adapter);

        registerForContextMenu(getListView());
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.context_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.new_provider:
                AlertDialog.Builder builder=new AlertDialog.Builder(this);
                final View layout=LayoutInflater.from(this).inflate(R.layout.dialog_layout,null);
                builder.setView(layout);
                builder.setTitle("Nuovo Provider");
                builder.setNegativeButton("Annulla",new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        dialog.dismiss();
                    }
                });
                builder.setPositiveButton("Salva", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        EditText title = (EditText) layout.findViewById(R.id.txt_title);
                        EditText url = (EditText) layout.findViewById(R.id.txt_url);
                        ProviderInfo pi=new ProviderInfo(title.getText().toString(),url.getText().toString());
                        provider.addProvider(pi);
                        adapter.notifyDataSetChanged();
                        dialog.dismiss();
                    }
                });

                builder.show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.manager_main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}