package videocorsi.esempi.newsreader.activities;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.CursorAdapter;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import videocorsi.esempi.newsreader.R;
import videocorsi.esempi.newsreader.beans.ArticleInfo;
import videocorsi.esempi.newsreader.beans.ProviderInfo;
import videocorsi.esempi.newsreader.database.DbManager;
import videocorsi.esempi.newsreader.parsing.RssParser;

/* Created by creareapp.com */

public class ManagerActivity extends ListActivity
{
    private CursorAdapter adapter=null;
    private DbManager db=new DbManager(this);
    private ProgressDialog progress=null;

    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        adapter=new CursorAdapter(this,db.getProviders(),false)
        {
            @Override
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup)
            {
                View v=LayoutInflater.from(context).inflate(R.layout.provider_layout,null);
                return v;
            }

            @Override
            public void bindView(View view, Context context, Cursor cursor)
            {
                TextView txt= (TextView) view.findViewById(R.id.title);
                txt.setText(cursor.getString(cursor.getColumnIndex("name")));
            }

            @Override
            public Object getItem(int position)
            {
                Cursor crs=getCursor();
                crs.moveToPosition(position);
                String name=crs.getString(crs.getColumnIndex("name"));
                String url=crs.getString(crs.getColumnIndex("url"));
                ProviderInfo pi=new ProviderInfo(name,url);
                return pi;
            }
        };
        getListView().setAdapter(adapter);

        registerForContextMenu(getListView());
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.context_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.new_provider:
                showDialog(null);
                break;
            case R.id.download:
                for(int i=0;i<adapter.getCount();i++)
                {
                    ProviderInfo tmp= (ProviderInfo) adapter.getItem(i);
                    new DownloadTask().execute(tmp.getUrl());
                }

        }
        return super.onOptionsItemSelected(item);
    }

    private void showDialog(final ProviderInfo pi)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        final View layout= LayoutInflater.from(this).inflate(R.layout.dialog_layout,null);
        builder.setView(layout);
        builder.setTitle("Nuovo Provider");
        builder.setNegativeButton("Annulla",new DialogInterface.OnClickListener()
        {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.dismiss();
            }
        });
        if (pi!=null)
        {
            EditText title= (EditText) layout.findViewById(R.id.txt_title);
            EditText url= (EditText) layout.findViewById(R.id.txt_url);
            title.setText(pi.getName());
            url.setText(pi.getUrl());
        }
        builder.setPositiveButton("Salva", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                EditText title= (EditText) layout.findViewById(R.id.txt_title);
                EditText url= (EditText) layout.findViewById(R.id.txt_url);

                ContentValues cv=new ContentValues();
                cv.put("name",title.getText().toString());
                cv.put("url",url.getText().toString());
                if (pi!=null)
                    db.updateProvider(cv,pi.getUrl());
                else
                    db.newProvider(cv);

                adapter.swapCursor(db.getProviders());

                dialog.dismiss();
            }
        });

        builder.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.manager_main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    private class DownloadTask extends AsyncTask<String,Integer,String>
    {

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            if (progress==null)
            {
                progress=new ProgressDialog(ManagerActivity.this);
                progress.setMessage("Download in corso....");
            }
            progress.setProgress(0);
            progress.show();
        }

        @Override
        protected String doInBackground(String... params)
        {
            URL url=null;

            try
            {
                    url=new URL(params[0]);
            }
            catch (MalformedURLException e)
            { return null;}

            StringBuffer buffer=null;
            try {
                BufferedReader reader=new BufferedReader(new InputStreamReader(url.openStream()));
                String tmp=null;
                buffer=new StringBuffer();
                while((tmp=reader.readLine())!=null)
                {
                    buffer.append(tmp);
                }
            } catch (IOException e)
            { return null;}

            List<ArticleInfo> list=RssParser.parseXML(buffer.toString());
            for(ArticleInfo ai: list)
                db.newArticle(ai);
            return buffer.toString();
        }

        @Override
        protected void onProgressUpdate(Integer... values)
        {
            super.onProgressUpdate(values);
            progress.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(String res)
        {
            super.onPostExecute(res);
            progress.dismiss();
            int idMsg=0;
            if (res!=null)
                idMsg=R.string.msg_download_ok;
            else
                idMsg=R.string.msg_download_ko;
            Toast.makeText(ManagerActivity.this,idMsg,Toast.LENGTH_LONG).show();
        }
    }
}