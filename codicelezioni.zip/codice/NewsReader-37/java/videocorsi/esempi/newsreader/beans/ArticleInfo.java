package videocorsi.esempi.newsreader.beans;

/* Created by creareapp.com */

import java.util.Date;

public class ArticleInfo
{
    private int id=0;
    private String title=null;
    private String url=null;
    private Date date=null;
    private boolean bookmark=false;

    public ArticleInfo(String title, String url)
    {
        this.title = title;
        this.url = url;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getShortUrl()
    {
        return getUrl().substring(0,40)+"...";
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isBookmark() {
        return bookmark;
    }

    public void setBookmark(boolean bookmark) {
        this.bookmark = bookmark;
    }
}
