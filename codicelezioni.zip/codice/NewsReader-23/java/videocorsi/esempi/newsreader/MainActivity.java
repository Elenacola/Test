package videocorsi.esempi.newsreader;
 
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;

public class MainActivity extends Activity 
{
    ProgressDialog progress=null;

    @Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
        progress=new ProgressDialog(this);
        progress.setMax(100);
        progress.setMessage(getString(R.string.progress_msg));
        progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

	}

	public void start(View v)
	{
        new BackgroundTask().execute();
	}

    private class BackgroundTask extends AsyncTask<Void,Integer,Void>
    {

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            progress.setProgress(0);
            progress.show();
        }

        @Override
        protected Void doInBackground(Void... params)
        {
            for(int i=0;i<10;i++)
            {
                try {
                    Thread.sleep(1200);
                    publishProgress(i*10);
                } catch (InterruptedException e)
                {

                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values)
        {
            super.onProgressUpdate(values);
            progress.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(Void aVoid)
        {
            super.onPostExecute(aVoid);
            progress.dismiss();
        }
    }

}

