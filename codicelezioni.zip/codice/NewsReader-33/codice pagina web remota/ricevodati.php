<?php
$database='link.txt';
$json = file_get_contents('php://input');
if ($json==FALSE)
{
	?>
<html>
<head>
<title>NewsReader</title>
<meta charset="UTF-8">
<style>
div.general
{
  width: 700px;
  display: block;
  margin-left: auto;
  margin-right: auto;
  text-align:center;
  border-radius: 15px;
}

div.centre
{
  font-size:350%;
  background-color:#b0c4de;
  margin-bottom:25px;
}

div.content
{
  background-color:#cccccc;
  font-size:150%;
  margin-top:10px;
}
</style>
</head>
<body>


	<?
	if (!file_exists($database))
	{
	   ?>
		<div class="general centre">Nessun articolo salvato</div>
	   <?}
	else
	{
		$data = json_decode(file_get_contents($database));
		?>
		<div class="general centre">Notizie salvate</div>
		<?
		foreach ($data as $key => $value)
		{?>
  			<div class="general content">
			<a href="<?echo $value->url?>"><?echo $value->title?></a><br>
			</div>
		<?
		}
		?>
			</body>
			</html>
		<?
	}
}
else
{
if (file_exists($database))
{
	$db_content=file_get_contents($database);
	$old_content = json_decode($db_content);
	$old_content[]=json_decode($json);
	$new_database=json_encode($old_content);
	file_put_contents($database, $new_database);
	echo '{"result":"Salvato articolo"}';
}
else 
{
	$new_content = json_decode($json);
	$new_database=json_encode(array($new_content));
	file_put_contents($database, $new_database);
	echo '{"result":"Salvato primo articolo"}';
}

}
?>
