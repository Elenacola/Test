package videocorsi.esempi.newsreader.activities;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import videocorsi.esempi.newsreader.R;
import videocorsi.esempi.newsreader.beans.ArticleInfo;
import videocorsi.esempi.newsreader.beans.ProviderInfo;
import videocorsi.esempi.newsreader.database.DbManager;

/* Created by creareapp.com */

public class ArticlesActivity extends ListActivity
{
    private CursorAdapter adapter=null;
    private DbManager db=new DbManager(this);

    @Override
    protected void onStart()
    {
        super.onStart();
        if (adapter==null)
        {
            adapter= new CursorAdapter(this, db.getArticles(), false) {
                @Override
                public View newView(Context context, Cursor cursor, ViewGroup viewGroup)
                {
                    View v=LayoutInflater.from(context).inflate(R.layout.article_layout,null);
                    return v;
                }

                @Override
                public void bindView(View view, Context context, final Cursor cursor)
                {
                    TextView txt= (TextView) view.findViewById(R.id.title);
                    txt.setText(cursor.getString(cursor.getColumnIndex("title")));
                    txt= (TextView) view.findViewById(R.id.url);
                    txt.setText(cursor.getString(cursor.getColumnIndex("url")).substring(0,40)+"...");

                    ImageButton btn= (ImageButton) view.findViewById(R.id.share);
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v)
                        {
                            int position=getListView().getPositionForView((RelativeLayout)v.getParent());
                            final ArticleInfo ai= (ArticleInfo) adapter.getItem(position);
                            Intent i=new Intent();
                            i.setAction(Intent.ACTION_SEND);
                            i.putExtra(Intent.EXTRA_TEXT,ai.getTitle()+"\n"+ai.getUrl());
                            i.setType("text/plain");
                            startActivity(i);
                        }
                    });
                    
                    btn= (ImageButton) view.findViewById(R.id.post);
                    btn.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int position=getListView().getPositionForView((RelativeLayout)v.getParent());
                            ArticleInfo ai= (ArticleInfo) adapter.getItem(position);
                            new AsyncTask<ArticleInfo, Void, String>() {
                                @Override
                                protected String doInBackground(ArticleInfo... params)
                                {
                                    try {

                                        ArticleInfo ai = params[0];
                                        URL paginaURL = new URL(getString(R.string.remote_url));
                                        HttpURLConnection connection = (HttpURLConnection) paginaURL.openConnection();

                                        JSONObject jsonParam = new JSONObject();
                                        jsonParam.put("title", ai.getTitle());
                                        jsonParam.put("url", ai.getUrl());
                                        connection.setDoOutput(true);

                                        OutputStreamWriter wr = new OutputStreamWriter(connection.getOutputStream());
                                        wr.write(jsonParam.toString());
                                        wr.flush();

                                        InputStream buffer = new BufferedInputStream(connection.getInputStream());
                                        String line = "";
                                        StringBuffer strbuffer = new StringBuffer();

                                        BufferedReader rd = new BufferedReader(new InputStreamReader(buffer));
                                        while ((line = rd.readLine()) != null) {
                                            strbuffer.append(line);
                                        }
                                        JSONObject jsresponse = new JSONObject(strbuffer.toString());
                                        return jsresponse.getString("result");

                                    } catch (MalformedURLException e) {
                                        e.printStackTrace();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }

                                    return null;
                                }

                                @Override
                                protected void onPostExecute(String s)
                                {
                                    String text=null;
                                    if (s!=null)
                                        text=s;
                                    else
                                        text="Salvataggio FALLITO";
                                        Toast.makeText(ArticlesActivity.this,text,Toast.LENGTH_LONG).show();
                                }
                            }.execute(ai);

                        }

                    });
                }

                @Override
                public Object getItem(int position)
                {
                    Cursor crs=getCursor();
                    crs.moveToPosition(position);
                    String title=crs.getString(crs.getColumnIndex("title"));
                    String url=crs.getString(crs.getColumnIndex("url"));
                    ArticleInfo pi=new ArticleInfo(title,url);
                    return pi;
                }


            };

            getListView().setAdapter(adapter);

            getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    ArticleInfo ai = (ArticleInfo) adapter.getItem(position);
                    WebView web = new WebView(ArticlesActivity.this);
                    web.setWebViewClient(new WebViewClient());
                    web.loadUrl(ai.getUrl());
                    AlertDialog.Builder dialog = new AlertDialog.Builder(ArticlesActivity.this);
                    dialog.setView(web);
                    dialog.setPositiveButton("Chiudi", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    dialog.show();
                }
            });

        }
        else
            adapter.swapCursor(db.getArticles());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        switch(id)
        {
            case R.id.second_activity:
                Intent i=new Intent(this,ManagerActivity.class);
                startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}