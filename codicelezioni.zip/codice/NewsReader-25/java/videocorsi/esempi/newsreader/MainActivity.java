package videocorsi.esempi.parsing;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import org.json.JSONArray;
import org.json.JSONException;

/* Created by creareapp.com */

public class MainActivity extends ListActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        String j=getString(R.string.json);
        String[] persone=null;

        try {
            JSONArray array=new JSONArray(j);
            persone=new String[array.length()];
            for(int i=0;i<array.length();i++)
            {
                String nome=array.getJSONObject(i).getString("nome");
                String cognome=array.getJSONObject(i).getString("cognome");
                persone[i]=nome+" "+cognome;
            }
        }
        catch (JSONException e)
        { }


        ArrayAdapter<String> aa=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,persone);
        setListAdapter(aa);
    }

}
