package videocorsi.esempi.newsreader;


/* Created by creareapp.com */

import android.content.Context;

public class DbManager
{
    private DbHelper helper = null;

    public DbManager(Context context)
    {
        helper=new DbHelper(context);
    }
}
