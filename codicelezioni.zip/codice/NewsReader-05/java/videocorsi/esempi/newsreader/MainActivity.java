package videocorsi.esempi.newsreader;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends Activity {

    private MyAdapter adapter=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NewsProvider provider=new NewsProvider();
        //String[] dati=new String[]{"cane","gatto","cavallo","gallo"};

        //ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,dati);
        adapter=new MyAdapter(provider.getArticles());
        ListView lv = (ListView) findViewById(R.id.lista);

        lv.setAdapter(adapter);
    }
}