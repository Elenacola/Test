package videocorsi.esempi.newsreader.activities;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.CursorAdapter;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import videocorsi.esempi.newsreader.R;
import videocorsi.esempi.newsreader.database.DbManager;

/* Created by creareapp.com */

public class ManagerActivity extends ListActivity
{
    private CursorAdapter adapter=null;
    private DbManager db=new DbManager(this);

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        adapter=new CursorAdapter(this,db.getProviders(),false)
        {
            @Override
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup)
            {
                View v=LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_1,null);
                return v;
            }

            @Override
            public void bindView(View view, Context context, Cursor cursor)
            {
                TextView txt= (TextView) view.findViewById(android.R.id.text1);
                txt.setText(cursor.getString(cursor.getColumnIndex("name")));
            }
        };
        getListView().setAdapter(adapter);

        registerForContextMenu(getListView());
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.context_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.new_provider:
                AlertDialog.Builder builder=new AlertDialog.Builder(this);
                final View layout= LayoutInflater.from(this).inflate(R.layout.dialog_layout,null);
                builder.setView(layout);
                builder.setTitle("Nuovo Provider");
                builder.setNegativeButton("Annulla",new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        dialog.dismiss();
                    }
                });
                builder.setPositiveButton("Salva", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                       EditText title= (EditText) layout.findViewById(R.id.txt_title);
                       EditText url= (EditText) layout.findViewById(R.id.txt_url);

                       ContentValues cv=new ContentValues();
                        cv.put("name",title.getText().toString());
                        cv.put("url",url.getText().toString());

                        db.newProvider(cv);

                        adapter.swapCursor(db.getProviders());

                       dialog.dismiss();
                    }
                });

                builder.show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.manager_main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}