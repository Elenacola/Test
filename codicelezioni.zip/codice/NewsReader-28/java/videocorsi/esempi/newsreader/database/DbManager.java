package videocorsi.esempi.newsreader.database;


/* Created by creareapp.com */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

import videocorsi.esempi.newsreader.beans.ArticleInfo;

public class DbManager
{
    private DbHelper helper = null;

    public DbManager(Context context)
    {
        helper=new DbHelper(context);
    }

    public void newProvider(ContentValues values)
    {
        SQLiteDatabase db=helper.getWritableDatabase();
        db.insert("providers",null,values);
    }

    public Cursor getProviders()
    {
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor crs=db.query("providers",null,null,null,null,null,null);

        return crs;
    }

    public void newArticle(ArticleInfo ai)
    {
        ContentValues cv=new ContentValues();
        cv.put("title",ai.getTitle());
        cv.put("url",ai.getUrl());
        helper.getWritableDatabase().insert("articles",null,cv);
    }

    public Cursor getArticles()
    {
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor crs=db.query("articles",null,null,null,null,null,null);

        return crs;
    }

}
