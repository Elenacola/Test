package videocorsi.esempi.newsreader.activities;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ArrayAdapter;
import android.widget.TextView;

import videocorsi.esempi.newsreader.R;
import videocorsi.esempi.newsreader.database.DbManager;

/* Created by creareapp.com */

public class ArticlesActivity extends ListActivity
{
    private CursorAdapter adapter=null;
    private DbManager db=new DbManager(this);

    @Override
    protected void onStart()
    {
        super.onStart();
        if (adapter==null)
        {
            adapter= new CursorAdapter(this, db.getArticles(), false) {
                @Override
                public View newView(Context context, Cursor cursor, ViewGroup viewGroup)
                {
                    View v=LayoutInflater.from(context).inflate(R.layout.article_layout,null);
                    return v;
                }

                @Override
                public void bindView(View view, Context context, Cursor cursor)
                {
                    TextView txt= (TextView) view.findViewById(R.id.title);
                    txt.setText(cursor.getString(cursor.getColumnIndex("title")));
                    txt= (TextView) view.findViewById(R.id.url);
                    txt.setText(cursor.getString(cursor.getColumnIndex("url")));
                }
            };

            getListView().setAdapter(adapter);
        }
        else
            adapter.swapCursor(db.getArticles());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        switch(id)
        {
            case R.id.second_activity:
                Intent i=new Intent(this,ManagerActivity.class);
                startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
}