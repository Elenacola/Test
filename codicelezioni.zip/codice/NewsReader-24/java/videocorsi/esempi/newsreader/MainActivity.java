package videocorsi.esempi.newsreader;
 
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends Activity 
{
    ProgressDialog progress=null;
    private static final String ADDRESS=
            "http://www.corsoandroid.it/webservice/rss/ansa.xml";

    @Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
        progress=new ProgressDialog(this);
        progress.setMax(100);
        progress.setMessage(getString(R.string.progress_msg));
	}

	public void start(View v)
	{
        new BackgroundTask().execute();
	}

    private class BackgroundTask extends AsyncTask<Void,Integer,String>
    {

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            progress.setProgress(0);
            progress.show();
        }

        @Override
        protected String doInBackground(Void... params)
        {
            URL url=null;

            try {
                url=new URL(ADDRESS);
            } catch (MalformedURLException e)
            { return null;}

            StringBuffer buffer=null;
            try {
                BufferedReader reader=new BufferedReader(new InputStreamReader(url.openStream()));
                String tmp=null;
                buffer=new StringBuffer();
                while((tmp=reader.readLine())!=null)
                {
                    buffer.append(tmp);
                }
            } catch (IOException e)
            { return null;}

            return buffer.toString();
        }

        @Override
        protected void onProgressUpdate(Integer... values)
        {
            super.onProgressUpdate(values);
            progress.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(String res)
        {
            super.onPostExecute(res);
            progress.dismiss();
            if (res!=null)
            {
                TextView txt= (TextView) findViewById(R.id.result);
                txt.setText(res);
            }
        }
    }

}

