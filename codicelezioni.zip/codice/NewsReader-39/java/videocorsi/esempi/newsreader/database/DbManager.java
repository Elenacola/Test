package videocorsi.esempi.newsreader.database;


/* Created by creareapp.com */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import videocorsi.esempi.newsreader.beans.ArticleInfo;

public class DbManager
{
    private DbHelper helper = null;

    public DbManager(Context context)
    {
        helper=new DbHelper(context);
    }

    public void newProvider(ContentValues values)
    {
        SQLiteDatabase db=helper.getWritableDatabase();
        db.insert("providers",null,values);
    }

    public void updateProvider(ContentValues values,String url)
    {
        SQLiteDatabase db=helper.getWritableDatabase();
        db.update("providers",values,"url=?",new String[]{url});
    }

    public Cursor getProviders()
    {
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor crs=db.query("providers",null,null,null,null,null,null);

        return crs;
    }

    public void newArticle(ArticleInfo ai)
    {
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm");
        ContentValues cv=new ContentValues();
        cv.put("title",ai.getTitle());
        cv.put("url",ai.getUrl());
        cv.put("date",format.format(ai.getDate()));
        try
        {
            helper.getWritableDatabase().insert("articles",null,cv);
        }
        catch(SQLiteException e)
        { }
    }

    public Cursor getArticles()
    {
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor crs=db.query("articles",null,null,null,null,null,"date DESC");

        return crs;
    }

    public Cursor getLastArticles()
    {
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor crs=db.query("articles",null,null,null,null,null,"date DESC","10");

        return crs;
    }

    public void setBookmark(int id, boolean bookmark)
    {
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues cv=new ContentValues();
        if (bookmark)
            cv.put("bookmark",Integer.valueOf(1));
        else
            cv.put("bookmark",Integer.valueOf(0));
        db.update("articles",cv,"_id=?",new String[]{Integer.toString(id)});
    }

    public void deleteProvider(String url)
    {
        SQLiteDatabase db=helper.getWritableDatabase();
        db.delete("providers","url=?",new String[]{url});
    }

}
