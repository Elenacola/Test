package videocorsi.esempi.newsreader;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;


/* Created by creareapp.com */

class Notizia
{
    private String titolo;
    private String url;

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String toString()
    {
        return getTitolo();
    }
}

public class MainActivity extends ListActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        List<Notizia> notizie=parseXML();
        ArrayAdapter<Notizia> aa=new ArrayAdapter<Notizia>(this,android.R.layout.simple_list_item_1,notizie);
        setListAdapter(aa);
    }

    private List<Notizia> parseXML()
    {
        List<Notizia> res=new ArrayList<Notizia>();
        DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
        DocumentBuilder builder=null;
        try {
            builder=factory.newDocumentBuilder();
        } catch (ParserConfigurationException e)
        { }

        try {
            Document doc=builder.parse(getAssets().open("notizie.xml"));
            doc.normalize();
            NodeList list=doc.getElementsByTagName("item");
            for(int i=0;i<list.getLength();i++)
            {
                Node n=list.item(i);
                if (n.getNodeType()==Node.ELEMENT_NODE)
                {
                    Element e= (Element) n;
                    Notizia notizia=new Notizia();
                    notizia.setTitolo(e.getElementsByTagName("title").item(0).getTextContent());
                    notizia.setUrl(e.getElementsByTagName("guid").item(0).getTextContent());
                    res.add(notizia);
                }
            }
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return res;
    }
}
