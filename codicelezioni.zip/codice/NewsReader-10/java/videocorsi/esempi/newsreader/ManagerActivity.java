package videocorsi.esempi.newsreader;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class ManagerActivity extends ListActivity {

    private MyAdapter adapter=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        NewsProvider provider=new NewsProvider();
        //String[] dati=new String[]{"cane","gatto","cavallo","gallo"};

        ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_list_item_1, provider.getProviders());
        //adapter=new MyAdapter(provider.getArticles());

        getListView().setAdapter(adapter);

        //TextView txt = (TextView) findViewById(R.id.testo);
        registerForContextMenu(getListView());
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        switch(id)
        {
            case R.id.second_activity:
                Toast.makeText(this,"Cliccato VOCE Context Menu", Toast.LENGTH_LONG).show();
                break;
        }
        return super.onContextItemSelected(item);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflate = getMenuInflater();
        inflate.inflate(R.menu.manager_main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        switch(id)
        {
            case R.id.new_provider:
                Toast.makeText(this,"Cliccato VOCE Option Menu",Toast.LENGTH_LONG).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }


}