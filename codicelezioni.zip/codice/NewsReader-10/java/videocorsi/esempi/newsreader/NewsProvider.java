package videocorsi.esempi.newsreader;

/* Created by creareapp.com */

import java.util.ArrayList;
import java.util.List;

public class NewsProvider
{
        private List<ArticleInfo> articles=null;
        private List<ProviderInfo> providers=null;


        public NewsProvider()
        {
            articles=new ArrayList<ArticleInfo>();
            providers=new ArrayList<ProviderInfo>();
            ArticleInfo article=new ArticleInfo("L'ambiente di lavoro per progettare applicazioni per Android",
                    "http://www.corsoandroid.it/l_ambiente_di_lavoro_per_progettare_applicazioni_per_android.html");
            articles.add(article);
            article=new ArticleInfo("ListView per creare Liste di Dati in Android",
                    "http://www.corsoandroid.it/listview_per_creare_liste_di_dati_in_android.html");
            articles.add(article);
            article=new ArticleInfo("Le pagine web in Android: Activity",
                    "http://www.corsoandroid.it/le_pagine_web_in_android_activity.html");
            articles.add(article);
            article=new ArticleInfo("Anatomia di un linear layout con testo immagine e bottone cliccabile",
                    "http://www.corsoandroid.it/anatomia_di_un_linear_layout_con_testo_immagine_e_bottone_cliccabile.html");
            articles.add(article);
            providers.add(new ProviderInfo("CorsoAndroid.it","http://www.corsoandroid.it"));
        }

    public List<ArticleInfo> getArticles()
    {
        return articles;
    }
    public List<ProviderInfo> getProviders()
    {
        return providers;
    }

}
