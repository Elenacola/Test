package videocorsi.esempi.newsreader;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

/* Created by creareapp.com */

public class ArticlesActivity extends ListActivity {

    private MyAdapter adapter=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        NewsProvider provider=new NewsProvider();
        //String[] dati=new String[]{"cane","gatto","cavallo","gallo"};

        //ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,dati);
        adapter=new MyAdapter(provider.getArticles());

        getListView().setAdapter(adapter);

        //TextView txt = (TextView) findViewById(R.id.testo);
        //registerForContextMenu(getListView());
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflate = getMenuInflater();
        inflate.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        switch(id)
        {
            case R.id.second_activity:
                //Toast.makeText(this,"Cliccato VOCE Option Menu",Toast.LENGTH_LONG).show();
                Intent i = new Intent(this, ManagerActivity.class);
                startActivity(i);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


}